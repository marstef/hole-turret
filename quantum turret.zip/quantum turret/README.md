# ExampleMod
An example of a simple mod for Mindustry.

## Importing

Simply download this repository as a zip, then import it through the `Mods` dialog in Mindustry. Or, unzip this repo inside Mindustry's `mods/` folder.

## Contributing

Feel free to submit more example content to this repository. For example sprites, I recommend re-coloring existing blocks and using the existing Mindustry palette.

## Want more mods?

Simon Woodburry-Forget has a list [here](https://simonwoodburyforget.github.io/mindustry-mods/).
If you want your mod on there, you can add it [here](https://github.com/SimonWoodburyForget/mindustry-mods/blob/master/CONTRIBUTING.md#adding-mods-to-the-listing).
